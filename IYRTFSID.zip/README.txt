﻿000000  00   00  0000     000000   0000000      000   000000   0000000          000000    0   0    00000000
 0000    00 00   0  0       00     00          00      0000    00     00        00         0 0     00
 0000     000    0000       00     0000000      000    0000    00     00        000000      0      00000000
 0000     000    0   0      00     00         000      0000    00     00   00   00         0 0     00
000000    000    0    0     00     00       000       000000   0000000     00   000000    0    0   00000000

Made in: C++
Creator: Alexei_sery
Malware mame: IYRTFSID
Running in: Windows XP And upping
Damage rate(Only destructive version): Destructive, cleaning MBR

THE WARNING!!! THIS SOFTWARE IS DEYSTROY YOUR COMPUTER. IF YOU DONT KNOW THIS, THEN PLEASE DELETE THIS FILES FROM YOUR COMPUTER OR RUN CLEAN VERSION OF THIS MALWARE, CLEAN VERSION CAN'T DEYSTROY COMPUTER. AND THIS PROGRAM HAVE EPILEPTIC EFFECTS AND NEED FOR DELETE THIS FILES
IF YOU EPILEPTIC THEN DELETE ALL!!!!!.

P.S AND RUN(DESTRUCTIVE VERSION) ONLY IN VIRTUAL MACHINE!

P.P.S AND REQUIRED SETUP Visual C++ 2010 x86, SETUP ALSO IN THIS FOLDER.

HELLO TO THIS COOL PEPOLES VIRUSCHECK, FELOFOX, PAN KOZA, ENDERMAN, VIRUSTECH, VIRUS NEW 17, HAPPY WIN XP/WISTLER, BYTE++, DAINEL MYSTLEVETS, UNDER MIND, OVERBAFER1, PRESS F32, MR.LOGONUI, MR.VIRUS, ANGRY COW, DES CONNECT, NO_IMAGE.PNG, НЕДОХАКЕРЫ AND ЕРМАКОВ)))

============================================================================================================================================
============================================================================================================================================

Сделано на: C++
Создатель: Alexei_sery
Имя вируса: IYRTFSID
Запускать на: Windows XP И выше
Уровень опасности(Только деструктивная версия): Destructive, стирает MBR

ПРЕДУПРЕЖДЕНИЕ!!! ЭТА ПРОГРАММА УНИЧТОЖИТ ВАШ КОМПЬЮТЕР. ЕСЛИ ВЫ НЕ ЗНАЕТЕ ЭТО, ТОГДА ПОЖАЛУЙСТА УДАЛИТЕ ЭТИ ФАЙЛЫ ИЗ ВАШЕГО КОМПЬЮТЕРА ИЛИ ЗАПУСТИТЕ CLEAN(ЧИСТУЮ) ВЕРСИЮ ЭТОГО ВИРУСА, КОТОРАЯ НЕ УНИЧТОЖИТ КОМПЬЮТЕР. И ЭТА ПРОГРАММА СОДЕРЖИТ ЭПИЛЕПСТИЧЕСКИЕ ЭФФЕКТЫ И ЕСЛИ ВЫ С ЭПИЛЕПСИЕЙ ТО УДАЛИТЕ ЭТО ВСЁ!!!!!

P.S И ЗАПУСКАТЬ(ДЕСТРУКТИВНУЮ ВЕРСИЮ) ТОЛЬКО НА ВИРТУАЛЬНОЙ МАШИНЕ!

P.P.S И ТРЕБУЕТСЯ УСТАНОВИТЬ Visual C++ 2010 x86, УСТАНОВЩИК ТОЖЕ В ЭТОЙ ПАПКЕ.

ПРИВЕТ ЭТИМ КРУТЫМ ЧЕЛАМ VIRUSCHECK, FELOFOX, PAN KOZA, ENDERMAN, VIRUSTECH, VIRUS NEW 17, HAPPY WIN XP/WISTLER, BYTE++, DAINEL MYSTLEVETS, UNDER MIND, OVERBAFER1, PRESS F32, MR.LOGONUI, MR.VIRUS, ANGRY COW, DES CONNECT, NO_IMAGE.PNG, НЕДОХАКЕРЫ И ЕРМАКОВУ)))

VirusCheck'у от алексея серого...

Привет, мне очень нравится твоя рубрика "Вирусы от подписчиков" и все твои видео и новые и старые.

Я хочу чтобы ты запустил этот вирус (Только на виртуалке).